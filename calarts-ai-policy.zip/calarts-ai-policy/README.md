AI Syllabus Statement Builder
A simple React-based tool to help faculty generate an AI policy statement for their syllabus.